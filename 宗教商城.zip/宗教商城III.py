-------------------
-- 核心用戶系統 --
-------------------
CREATE TABLE users (
    user_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    avatar_url TEXT,
    membership_level VARCHAR(20) DEFAULT '普通' 
      CHECK (membership_level IN ('普通', '信徒', '法師')),
    karma_points INT DEFAULT 0 CHECK (karma_points >= 0),
    fu_coins DECIMAL(10,2) DEFAULT 0.00 CHECK (fu_coins >= 0),
    religious_cert JSONB, -- 存儲皈依證/法會認證等宗教身份信息
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE users IS '用戶主表，包含宗教認證狀態與數字資產';
COMMENT ON COLUMN users.religious_cert IS '存儲加密後的宗教身份認證數據';

-------------------
-- 商品服務體系 --
-------------------
CREATE TABLE listings (
    item_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(user_id),
    item_type VARCHAR(20) NOT NULL 
      CHECK (item_type IN ('physical', 'service', 'digital', 'handmade')),
    category VARCHAR(50) NOT NULL 
      CHECK (category IN ('法物', '經書', '念珠', '唐卡', '法會服務', '修行用品')),
    title VARCHAR(100) NOT NULL,
    description TEXT,
    attributes JSONB NOT NULL, -- 類型專用屬性
    price DECIMAL(10,2) CHECK (price >= 0),
    karma_price INT, -- 功德點兌換價
    status VARCHAR(20) DEFAULT 'draft' 
      CHECK (status IN ('draft', 'pending', 'approved', 'rejected')),
    audit_trail JSONB[], -- 審核記錄
    blessing_info JSONB, -- 開光信息
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE listings IS '統一商品/服務列表';
COMMENT ON COLUMN listings.attributes IS '動態屬性，例：法物={材質,尺寸}, 服務={時長,地點}';
COMMENT ON COLUMN listings.blessing_info IS '包含開光法師、日期、寺院信息';

-- 宗教特色枚舉類型
CREATE TYPE dharma_service_type AS ENUM (
    '共修活動', '法器維護', '法會義工', '經書抄寫', '齋食供應'
);

CREATE TABLE services (
    service_id UUID PRIMARY KEY REFERENCES listings(item_id),
    service_type dharma_service_type NOT NULL,
    location GEOGRAPHY(Point,4326), -- 服務地點坐標
    duration INTERVAL,
    max_participants INT
);

COMMENT ON TABLE services IS '宗教服務擴展信息';

-------------------
-- 交易管理系統 --
-------------------
CREATE TABLE orders (
    order_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(user_id),
    total_amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(20) 
      CHECK (payment_method IN ('paypal', 'karma', 'fu', 'mixed')),
    karma_used INT DEFAULT 0,
    fu_used DECIMAL(10,2) DEFAULT 0,
    coupon_used VARCHAR(20),
    order_status VARCHAR(20) DEFAULT 'pending'
      CHECK (order_status IN ('pending', 'paid', 'shipped', 'completed')),
    dharma_notes TEXT, -- 宗教需求備注
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE order_items (
    order_item_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID REFERENCES orders(order_id),
    item_id UUID REFERENCES listings(item_id),
    quantity INT NOT NULL CHECK (quantity > 0),
    is_service BOOLEAN NOT NULL
);

COMMENT ON COLUMN orders.dharma_notes IS '可存放供佛要求、回向文等宗教信息';

-------------------
-- 宗教審核系統 --
-------------------
CREATE TABLE audits (
    audit_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id UUID REFERENCES listings(item_id),
    auditor_id UUID REFERENCES users(user_id),
    audit_type VARCHAR(20) NOT NULL
      CHECK (audit_type IN ('initial', 'appeal', 'periodic')),
    result VARCHAR(10) NOT NULL CHECK (result IN ('approved', 'rejected')),
    comments TEXT,
    rule_violations JSONB, -- 違規條目記錄
    created_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE audits IS '包含AI審核與人工審核記錄';
COMMENT ON COLUMN audits.rule_violations IS '存儲觸發的具體審核規則條目';

-------------------
-- 優惠系統 --
-------------------
CREATE TABLE coupons (
    coupon_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(20) UNIQUE NOT NULL,
    discount_type VARCHAR(10) CHECK (discount_type IN ('percent', 'fixed')),
    value DECIMAL(10,2) NOT NULL,
    min_order DECIMAL(10,2) DEFAULT 0,
    applicable_to JSONB, -- 適用商品類別
    valid_from DATE NOT NULL,
    valid_until DATE NOT NULL,
    religious_restriction BOOLEAN DEFAULT FALSE -- 信徒專屬
);

-------------------
-- 索引優化 --
-------------------
CREATE INDEX idx_listings_category ON listings USING gin(category);
CREATE INDEX idx_services_location ON services USING gist(location);
CREATE INDEX idx_users_karma ON users(karma_points);

-- 分區表示例（按年分區的交易記錄）
CREATE TABLE transactions_2023 PARTITION OF transactions
    FOR VALUES FROM ('2023-01-01') TO ('2024-01-01');
SELECT s.*, ST_Distance(location, ST_MakePoint(121.5,25.0)) as distance
FROM services s
JOIN listings l ON s.service_id = l.item_id
WHERE l.category = '法會服務'
  AND l.status = 'approved'
  AND ST_DWithin(location, ST_MakePoint(121.5,25.0)::geography, 5000)
ORDER BY distance;
