CREATE TABLE religious_certification (
    cert_id UUID PRIMARY KEY,
    user_id VARCHAR(255) REFERENCES users(uid),
    cert_type VARCHAR(20) CHECK(cert_type IN ('皈依證', '法會參與', '寺院推薦')),
    cert_data JSONB NOT NULL,  -- 存證件掃描件/參與記錄
    verification_status VARCHAR(15) DEFAULT 'pending',
    verified_by VARCHAR(255),  -- 認證法師ID
    valid_until DATE,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE member_benefits (
    level VARCHAR(10) PRIMARY KEY,
    discount_rate DECIMAL(3,2),
    monthly_karma INT,  -- 每月贈送功德點
    access_rights JSONB  -- 特殊權限
);
class DharmaCertification:
    CERT_REQUIREMENTS = {
        '皈依證': {
            'fields': ['皈依日期', '寺院名稱', '法師印章'],
            'validation': 'verify_temple_seal'
        },
        '法會參與': {
            'fields': ['法會名稱', '參與日期', '主辦寺院'],
            'validation': 'check_event_records'
        },
        '寺院推薦': {
            'fields': ['推薦法師', '推薦理由'],
            'validation': 'verify_monk_signature'
        }
    }

    @classmethod
    def submit_certification(cls, user_id, cert_type, evidence):
        required_fields = cls.CERT_REQUIREMENTS[cert_type]['fields']
        validate_fields(evidence, required_fields)
        
        # 加密存儲敏感數據
        encrypted_data = encrypt(evidence, KEY_MANAGER.get_key('cert'))
        
        db.insert_certification({
            'user_id': user_id,
            'cert_type': cert_type,
            'cert_data': encrypted_data,
            'status': 'pending'
        })
        trigger_verification(cert_type, user_id)

    @staticmethod
    def verify_temple_seal(data):
        seal_img = data.get('法師印章')
        return TempleSealValidator.validate(seal_img)
def auto_verify_certification(cert_id):
    cert = get_certification(cert_id)
    
    if cert['cert_type'] == '法會參與':
        # 對接寺院法會記錄系統
        return DharmaEventAPI.check_attendance(
            user_id=cert['user_id'],
            event_name=cert['data']['法會名稱'],
            date=cert['data']['參與日期']
        )
        
    elif cert['cert_type'] == '寺院推薦':
        # 驗證法師數字簽名
        return verify_digital_signature(
            content=cert['data']['推薦理由'],
            signature=cert['data']['signature'],
            monk_id=cert['data']['推薦法師']
        )
class BenefitManager:
    BENEFIT_TIERS = {
        '初級': {
            'discount': 0.10,
            'karma': 500,
            'access': ['法物預購']
        },
        '中級': {
            'discount': 0.20,
            'karma': 1000,
            'access': ['法物預購', '共修活動']
        },
        '高級': {
            'discount': 0.30,
            'karma': 2000,
            'access': ['法物預購', '共修活動', '法師咨詢']
        }
    }

    @classmethod
    def apply_benefits(cls, user):
        tier = get_user_tier(user.id)
        benefits = cls.BENEFIT_TIERS[tier]
        
        # 每月初發放權益
        if is_first_day_of_month():
            add_karma(user.id, benefits['karma'])
            grant_access(user.id, benefits['access'])
        
        # 實時折扣應用
        return benefits['discount']
def apply_religious_discount(user, total):
    if not user.is_verified_member:
        return total
    
    discount_rate = BenefitManager.get_discount_rate(user.tier)
    max_discount = total * 0.5  # 最高50%折扣限制
    
    discount = min(total * discount_rate, max_discount)
    
    # 顯示宗教特色提示
    st.toast(f"三寶加持，獲得{discount_rate*100}%功德折扣！")
    
    return total - discount
def show_certification_flow():
    st.header("🙏 信徒認證")
    
    cert_type = st.radio("選擇認證方式", 
        options=["皈依證認證", "法會參與認證", "寺院推薦認證"],
        help="至少需完成其中一種認證"
    )
    
    with st.form("認證表單"):
        if cert_type == "皈依證認證":
            col1, col2 = st.columns(2)
            with col1:
                refuge_date = st.date_input("皈依日期")
                temple_name = st.selectbox("皈依寺院", get_temple_list())
            with col2:
                seal_upload = st.file_uploader("上傳皈依證掃描件", type=['pdf','jpg'])
                
        elif cert_type == "法會參與認證":
            # ...其他認證類型表單
            
        if st.form_submit_button("提交認證"):
            handle_cert_submission(cert_type, form_data)
def show_member_badge():
    if current_user.is_verified:
        badge_type = {
            '初級': '🥉',
            '中級': '🥈', 
            '高級': '🥇'
        }[current_user.tier]
        
        st.markdown(f"""
        <div class="member-badge {current_user.tier}">
            {badge_type} {current_user.tier}信徒
            <div class="benefits">
                優惠: {current_user.discount*100}% | 
                功德加成: +{current_user.karma_rate}x
            </div>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.warning("完成信徒認證解鎖專屬優惠")
from cryptography.fernet import Fernet

class CertEncryptor:
    _key = Fernet.generate_key()
    
    @classmethod
    def encrypt_data(cls, data):
        cipher_suite = Fernet(cls._key)
        return cipher_suite.encrypt(data.encode())
    
    @classmethod
    def decrypt_data(cls, encrypted):
        cipher_suite = Fernet(cls._key)
        return cipher_suite.decrypt(encrypted).decode()
def store_on_blockchain(cert_data):
    block = {
        'timestamp': datetime.now().isoformat(),
        'user_hash': hash_user_id(cert_data['user_id']),
        'cert_hash': sha256(cert_data['cert_data']).hexdigest(),
        'verified_by': cert_data['verified_by']
    }
    BlockchainAPI.add_block(block)
def calculate_spiritual_level(user_id):
    base = get_certification_count(user_id) * 10
    karma = get_karma_points(user_id) // 100
    events = get_event_participation(user_id) * 5
    return min(base + karma + events, 100) // 20  # 每20分升一級
def dharma_event_benefits(event_type):
    benefits = {
        '禪七': {'discount_boost': 0.15, 'karma_multiplier': 2},
        '傳戒大典': {'discount_boost': 0.25, 'access': ['袈裟預購']},
        '佛誕日': {'discount_boost': 0.30, 'karma_multiplier': 3}
    }
    return benefits.get(event_type, {})
