CREATE TABLE services (
    service_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id VARCHAR(255) REFERENCES users(uid),
    service_type VARCHAR(20) CHECK(service_type IN (
        '運送', '打掃', '清潔', '煮菜', '按摩', '其他'
    )),
    title VARCHAR(100),
    description TEXT,
    time_unit INT NOT NULL,  -- 以15分鍾爲基本單位
    karma_per_unit INT DEFAULT 10,  -- 每分鍾功德值
    available_times JSONB,  -- 可用時間段
    status VARCHAR(10) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT NOW(),
    CHECK (karma_per_unit BETWEEN 5 AND 50)  -- 限制功德值範圍
);

CREATE TABLE service_transactions (
    tx_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    service_id UUID REFERENCES services(service_id),
    provider_id VARCHAR(255) REFERENCES users(uid),
    receiver_id VARCHAR(255) REFERENCES users(uid),
    scheduled_time TIMESTAMP,
    actual_duration INT,  -- 實際服務分鍾數
    karma_transferred INT,
    status VARCHAR(20) CHECK(status IN (
        'pending', 'confirmed', 'disputed', 'completed'
    )),
    provider_rating INT CHECK(provider_rating BETWEEN 1 AND 5),
    receiver_rating INT CHECK(receiver_rating BETWEEN 1 AND 5)
);
class ServiceValuator:
    BASE_RATES = {
        '運送': 8,     # 每分鍾8功德點
        '打掃': 10,
        '清潔': 12,
        '煮菜': 15,
        '按摩': 20,
        '其他': 10
    }

    @classmethod
    def calculate_karma(cls, service_type, duration, user_rank):
        base = cls.BASE_RATES[service_type]
        multiplier = 1 + (user_rank * 0.1)  # 每級信用等級+10%
        return int(base * duration * multiplier)
def find_service_matches(user_needs):
    # 基于位置、時間、信用度的匹配
    query = """
        SELECT * FROM services 
        WHERE service_type = %(type)s
          AND available_times @> %(time_range)s
          AND ST_DWithin(location, %(user_loc)s, 5000)  -- 5公裏範圍
        ORDER BY 
          user_credit_score DESC,
          karma_per_unit ASC
        LIMIT 10
    """
    return db.execute(query, {
        'type': user_needs['type'],
        'time_range': user_needs['time_window'],
        'user_loc': user_needs['location']
    })
class ServiceVerifier:
    @staticmethod
    def confirm_service(tx_id):
        # 多方驗證流程
        tx = get_transaction(tx_id)
        
        # 1. 雙方确認
        if not (tx.provider_confirm and tx.receiver_confirm):
            raise ValidationError("需雙方确認")
            
        # 2. 時間地理驗證
        if not validate_time_location(tx):
            raise ValidationError("服務時間地點不匹配")
            
        # 3. 自動抽查機制
        if random.random() < 0.1:  # 10%隨機抽查
            if not third_party_verification(tx):
                mark_as_disputed(tx_id)
                
        # 4. 功德轉移
        transfer_karma(
            from_user=tx.receiver_id,
            to_user=tx.provider_id,
            amount=tx.karma_transferred
        )
def handle_dispute(tx_id):
    dispute = get_dispute_details(tx_id)
    
    # 自動仲裁流程
    if dispute['evidence']['photo_proof'] and dispute['evidence']['chat_log']:
        auto_judge(tx_id)
    else:
        # 轉人工仲裁
        assign_to_moderator(tx_id)
        
    # 信用分扣除機制
    if dispute['result'] == 'provider_fault':
        deduct_credit_score(dispute['provider_id'], 20)
    elif dispute['result'] == 'receiver_fault':
        deduct_credit_score(dispute['receiver_id'], 15)
def post_service_form():
    with st.form("發布服務"):
        service_type = st.selectbox("服務類型", options=ServiceValuator.BASE_RATES.keys())
        time_units = st.slider("每次服務時長（15分鍾爲單位）", 1, 8, 2)
        schedule = st.multiselect("可服務時間", 
            options=["周一上午", "周一下午", ...],
            default=["周六上午", "周日下午"]
        )
        
        if st.form_submit_button("發布"):
            karma_value = ServiceValuator.calculate_karma(
                service_type, 
                duration=time_units*15,
                user_rank=get_user_credit()
            )
            db.insert_service({
                'user_id': current_user.id,
                'service_type': service_type,
                'time_unit': time_units,
                'karma_per_unit': karma_value//time_units,
                'available_times': schedule
            })
def show_service_market():
    st.header("🧹 服務功德市場")
    
    col1, col2 = st.columns([1,3])
    with col1:
        service_filter = st.multiselect("服務類型", options=ServiceValuator.BASE_RATES.keys())
        max_karma = st.slider("最大功德值/分鍾", 5, 50, 30)
        
    with col2:
        services = db.get_services(filters={
            'types': service_filter,
            'max_karma': max_karma
        })
        
        for service in services:
            with st.expander(f"{service['title']} - {service['karma_per_unit']}功德/分鍾"):
                show_service_detail(service)
                if st.button("預約", key=service['id']):
                    initiate_service_transaction(service)
class CreditSystem:
    BASE_SCORE = 100
    WEIGHTS = {
        'completed_tx': 0.4,
        'positive_ratings': 0.3,
        'response_time': 0.2,
        'dispute_rate': -0.5
    }

    @classmethod
    def calculate_credit(cls, user_id):
        stats = get_user_stats(user_id)
        score = cls.BASE_SCORE
        
        score += stats['completed_tx'] * 0.5 * cls.WEIGHTS['completed_tx']
        score += stats['avg_rating'] * 20 * cls.WEIGHTS['positive_ratings']
        score += (1 - stats['avg_response_hours']/24) * 100 * cls.WEIGHTS['response_time']
        score -= stats['dispute_rate'] * 100 * abs(cls.WEIGHTS['dispute_rate'])
        
        return max(min(score, 200), 0)  # 信用分區間0-200
def validate_service_session():
    # 實時位置驗證
    if not validate_location_match(request.location, tx.location):
        send_alert("服務位置異常")
        
    # 人臉識別抽查
    if random.random() < 0.05:
        require_live_face_check()
        
    # 服務過程錄音（可選）
    if st.session_state.get('enable_audio_record'):
        start_voice_recording()
def group_service_bonus():
    if is_group_service(service_type):
        karma = calculate_karma(...)
        if during_ceremony_time():  # 法會期間
            return karma * 2
        elif with_monk_participation():  # 有法師參與
            return karma * 1.5
    return karma
def create_donation_service():
    if service_type == '供養服務':
        # 30%功德轉入寺廟公共賬戶
        transferred = tx.karma * 0.3
        add_to_temple_karma(transferred)
        notify_user(f"{transferred}功德已供養三寶")
