import streamlit as st
from streamlit_material_components import material_layout
from app.components import auth
from app.utils.material import apply_theme

# 應用Material主題
apply_theme()

# 初始化數據庫
from app.database.init_db import init_database
init_database()

# 主布局
with material_layout():
    st.title("🙏 法緣云商城")
    
    # 登錄狀態管理
    auth_status = auth.check_auth()
    
    # 導航菜單
    if auth_status.logged_in:
        menu = {
            "商品市場": app.pages.marketplace,
            "服務功德": app.pages.services,
            "我的修行": app.pages.dashboard
        }
        if auth_status.is_admin:
            menu["法師後台"] = app.pages.admin
        
        choice = st.sidebar.radio("導航", list(menu.keys()))
        menu[choice].show()
    else:
        auth.show_login()
def apply_theme():
    st.set_page_config(
        page_title="法緣云商城",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # 自定義Material主題
    st.markdown("""
    <style>
    .stApp { background-color: #f5f5f5; }
    .material-card { 
        border-radius: 15px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        padding: 20px;
        background: white;
    }
    .dharma-primary { color: #3f51b5; }
    </style>
    """, unsafe_allow_html=True)
def buddhist_certification_flow():
    with st.form("三寶認證"):
        col1, col2 = st.columns(2)
        with col1:
            st.image("assets/three_jewels.png")
        with col2:
            step = st.progress(0)
            step1 = st.checkbox("我皈依佛")
            step2 = st.checkbox("我皈依法")
            step3 = st.checkbox("我皈依僧")
            
            if st.form_submit_button("發愿認證"):
                if all([step1, step2, step3]):
                    grant_member_status("信徒")
                    st.success("認證成功！")
                else:
                    st.error("請完整發愿三皈依")
