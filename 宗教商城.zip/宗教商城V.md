以下是為宗教云商城新增手作商品審核上架系統的完整解決方案，采用「三階聖檢」審核機制确保宗教合規性：

---

### 一、手作商品審核架構
```mermaid
graph TD
    A[用戶提交] --> B[AI初篩]
    B --> C{是否宗教物品?}
    C -->|是| D[法師審核]
    C -->|否| E[常規審核]
    D --> F[法脈認證]
    E --> G[最終發布]
    F --> G
```

---

### 二、數據庫擴展設計

1. **手作商品專用表**
```sql
CREATE TABLE handmade_items (
    item_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id VARCHAR(255) REFERENCES users(uid),
    craft_type VARCHAR(50) CHECK(craft_type IN (
        '佛具', '法衣', '念珠', '唐卡', '供品', '其他'
    )),
    materials JSONB,  -- 材料成分
    creation_process TEXT,
    spiritual_significance TEXT,  -- 宗教意義說明
    status VARCHAR(20) DEFAULT 'pending',
    audit_history JSONB[],  -- 審核記錄
    created_at TIMESTAMP DEFAULT NOW(),
    blessed_by VARCHAR(255) REFERENCES monks(id)  -- 開光法師
);

CREATE TABLE craft_audits (
    audit_id UUID PRIMARY KEY,
    item_id UUID REFERENCES handmade_items(item_id),
    auditor_id VARCHAR(255),  -- 審核人員/法師ID
    audit_result VARCHAR(10),
    comments TEXT,
    audit_time TIMESTAMP
);
```

---

### 三、審核流程實現

1. **宗教合規性檢查（app/audit/religious_check.py）**
```python
class DharmaValidator:
    SACRED_PATTERNS = load_patterns('data/sacred_symbols.yaml')  # 加載宗教符號庫
    
    @classmethod
    def validate_craft(cls, item_data):
        # 1. 圖像符號檢測
        if not cls.check_images(item_data['images']):
            return False, "含未授權宗教符號"
            
        # 2. 經文引用驗證
        if cls.has_improper_sutra_usage(item_data['description']):
            return False, "經文引用不符合規範"
            
        # 3. 法脈傳承驗證
        if item_data['craft_type'] in ['唐卡', '法衣'] and not item_data.get('lineage_proof'):
            return False, "需提供法脈傳承證明"
            
        return True, ""

    @staticmethod
    def check_images(images):
        for img in images:
            results = vision_api.detect_symbols(img.url)
            if any(symbol in cls.SACRED_PATTERNS['restricted'] for symbol in results):
                return False
        return True
```

2. **三階審核工作流（app/audit/workflow.py）**
```python
def audit_workflow(item_id):
    item = get_item(item_id)
    
    # 第一階段：AI自動審核
    ai_result = AIChecker.check(item)
    if not ai_result.approved:
        reject_item(item_id, ai_result.reasons)
        return

    # 第二階段：分類路由
    if item['craft_type'] in ['唐卡', '法衣', '佛像']:
        assign_to_monk_audit(item_id)
    else:
        assign_to_human_audit(item_id)

    # 第三階段：最終認證
    if item.needs_blessing:
        require_temple_blessing(item_id)
```

---

### 四、用戶提交系統

1. **手作商品提交表單（app/components/craft_submit.py）**
```python
def craft_submission_form():
    with st.form("法寶提交"):
        cols = st.columns([3, 1])
        with cols[0]:
            title = st.text_input("法寶名稱", max_chars=50)
            craft_type = st.selectbox("作品類型", options=HANDMADE_CATEGORIES)
            materials = st.multiselect("使用材料", options=APPROVED_MATERIALS)
            
        with cols[1]:
            st.image("assets/craft_example.png", width=150)
            
        creation_process = st.text_area("制作過程 (需包含宗教意義)", height=200)
        uploads = st.file_uploader("上傳作品照片 (最多5張)", 
                                 type=['jpg','png'], 
                                 accept_multiple_files=True)
        
        if st.form_submit_button("提交審核"):
            if validate_submission():
                create_craft_item({
                    'title': title,
                    'craft_type': craft_type,
                    'materials': materials,
                    'process': creation_process,
                    'images': process_uploads(uploads)
                })
                st.success("已提交至三寶審核系統")
```

2. **審核狀態追蹤（app/components/audit_status.py）**
```python
def show_audit_progress(item_id):
    audit_steps = [
        {'name': 'AI初篩', 'icon': '🤖'},
        {'name': '法脈認證', 'icon': '🕉️'},
        {'name': '住持終審', 'icon': '👴'}
    ]
    
    current_step = get_current_step(item_id)
    
    with st.status("審核進度", expanded=True) as status:
        for step in audit_steps:
            if step['name'] == current_step['name']:
                st.markdown(f"**{step['icon']} {step['name']}** (進行中)")
                st.progress(current_step['progress'])
            else:
                st.markdown(f"{step['icon']} ~~{step['name']}~~")
                
        if current_step['name'] == '住持終審':
            st.write("預計完成時間：佛歷 2567 年 結夏安居前")
```

---

### 五、法師審核後台

1. **唐卡專項審核工具（app/audit/tangka.py）**
```python
def tangka_audit_interface():
    st.header("🖼️ 唐卡聖像審核系統")
    
    tangka = get_next_tangka()
    cols = st.columns([2, 3])
    
    with cols[0]:
        st.image(tangka.detail_scan, caption="細節掃描圖")
        st.metric("比例精度", f"{calculate_proportion(tangka)}%")
        
    with cols[1]:
        with st.container(border=True):
            st.write("**法脈驗證**")
            if tangka.lineage != "勉唐派":
                st.error("⚠️ 非認證傳承畫派")
            else:
                st.success("✅ 認證勉唐派傳承")
                
            st.write("**度量經符合度**")
            render_proportion_chart(tangka)
            
        st.checkbox("忿怒相已模糊處理", value=tangka.is_obscured)
        st.checkbox("主尊位置正确", value=tangka.has_correct_layout)
        
    if st.button("開光認證"):
        update_blessing_status(tangka.id, blessed=True)
```

---

### 六、安全與合規措施

1. **數字水印系統**
```python
def apply_watermark(image):
    watermark = Image.open("assets/dharma_seal.png").resize((200,200))
    base = Image.open(image).convert("RGBA")
    position = (base.width-220, base.height-220)
    base.paste(watermark, position, watermark)
    return base.save("watermarked.jpg")
```

2. **材料溯源驗證**
```python
class MaterialValidator:
    FORBIDDEN_MATERIALS = ['象牙', '犀角', '珍稀木材']
    APPROVED_SOURCES = ['寺廟供給', '認證商家']
    
    @classmethod
    def validate_materials(cls, materials):
        if any(mat in cls.FORBIDDEN_MATERIALS for mat in materials):
            return False, "包含違禁材料"
            
        if not all(source in cls.APPROVED_SOURCES for mat in materials.values()):
            return False, "材料來源未認證"
            
        return True, ""
```

---

### 七、宗教特色運營方案

1. **年度聖作大展**
```python
def holy_craft_exhibition():
    featured_items = get_items_by_rating(min_rating=4.5)
    carousel = st.container()
    
    for item in featured_items:
        with carousel:
            st.markdown(f"## {item['title']} - {item['creator']}")
            st.image(item['main_image'], use_column_width=True)
            st.caption(f"✨ 累計功德值：{item['karma_points']}")
            if st.button("隨喜贊嘆", key=item['id']):
                add_karma(item['creator'], 10)
```

---

### 實施步驟建議：
1. 新增手作商品數據模型
2. 開發三階審核工作流
3. 實現法師專用審核界面
4. 集成材料溯源系統
5. 部署數字水印服務
6. 舉辦首批聖作征集活動
7. 建立用戶創作指引體系

系統特點：
- 佛造像度量經自動校驗
- 法脈傳承區塊鏈存證
- 材料來源可追溯
- 審核過程可視化
- 數字開光認證
- 聖作展覽功能

通過此系統可實現：
- 居士手作佛珠經AI+法師審核後流通
- 唐卡畫師在線提交作品進行傳承認證
- 使用回收供花制作手工藝品需材料申報
- 優秀作品自動入選年度佛教藝術展

建議配套措施：
1. 編制《佛教手作物品制作指南》
2. 認證寺廟開設手作課程
3. 建立材料供給合作社
4. 舉辦線上開光法會
5. 優秀創作者授予"妙手佛心"徽章
