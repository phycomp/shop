以下是為宗教云商城增加會員點數、優惠券、虛藕貨幣系統的完整解決方案，采用三合一復合支付體系設計：

---

### 一、經濟系統架構設計
```mermaid
graph TD
    A[支付系統] --> B[會員功德點]
    A --> C[法緣券]
    A --> D[福幣]
    B --> E[功德累計規則]
    C --> F[優惠券管理]
    D --> G[虛藕貨幣兌換]
```

---

### 二、數據庫設計（PostgreSQL）

1. **用戶資產表**
```sql
CREATE TABLE user_assets (
    user_id VARCHAR(255) PRIMARY KEY REFERENCES users(uid),
    karma_points INT DEFAULT 0 CHECK(karma_points >= 0),  -- 功德點
    fu_coins DECIMAL(10,2) DEFAULT 0.00 CHECK(fu_coins >= 0), -- 福幣
    last_update TIMESTAMP DEFAULT NOW()
);

CREATE TABLE coupons (
    coupon_id SERIAL PRIMARY KEY,
    code VARCHAR(20) UNIQUE,
    coupon_type VARCHAR(10) CHECK(coupon_type IN ('percentage', 'fixed')), 
    value DECIMAL(10,2),
    min_order DECIMAL(10,2) DEFAULT 0.00,
    applicable_to VARCHAR(50)[] DEFAULT '{}', -- 適用商品類別
    valid_from TIMESTAMP,
    valid_until TIMESTAMP,
    usage_limit INT DEFAULT 1,
    used_count INT DEFAULT 0,
    religious_restriction BOOLEAN DEFAULT FALSE -- 宗教專屬優惠
);
```

2. **交易流水表**
```sql
CREATE TABLE asset_transactions (
    tx_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id VARCHAR(255) REFERENCES users(uid),
    tx_type VARCHAR(20) CHECK(tx_type IN ('earn', 'redeem', 'exchange', 'purchase')),
    asset_type VARCHAR(10) CHECK(asset_type IN ('karma', 'fu', 'coupon')),
    amount DECIMAL(10,2),
    balance_snapshot JSONB,
    related_order VARCHAR(255),
    tx_time TIMESTAMP DEFAULT NOW()
);
```

---

### 三、核心業務邏輯實現

1. **復合支付計算器（app/payment/calculator.py）**
```python
class PaymentCalculator:
    @staticmethod
    def calculate_total(order, user_assets, selected_coupon=None):
        # 初始金額
        total = sum(item['price'] * item['quantity'] for item in order['items'])
        
        # 優惠券應用
        if selected_coupon:
            total = CouponManager.apply_coupon(total, selected_coupon)
            
        # 功德點抵扣（1點=0.01元）
        max_karma_use = min(user_assets['karma_points'], total * 100)
        karma_discount = min(order.get('use_karma', 0), max_karma_use) / 100
        total -= karma_discount
        
        # 福幣支付
        fu_payment = min(user_assets['fu_coins'], total)
        total -= fu_payment
        
        return {
            'original_total': total + karma_discount + fu_payment,
            'final_total': max(total, 0),
            'karma_used': karma_discount,
            'fu_used': fu_payment,
            'coupon_used': selected_coupon['code'] if selected_coupon else None
        }
```

2. **功德點獎勵系統（app/assets/karma.py）**
```python
class KarmaSystem:
    RULES = {
        'purchase': lambda amt: amt * 0.1,  # 消費1元得10功德點
        'daily_login': 50,
        'donation': lambda amt: amt * 100,  # 供養1元得100功德點
        'share_product': 20
    }

    @classmethod
    def award_points(cls, user_id, action_type, **kwargs):
        points = cls._calculate_points(action_type, kwargs)
        with db.transaction():
            db.execute(
                "UPDATE user_assets SET karma_points = karma_points + %s WHERE user_id = %s",
                (points, user_id)
            )
            log_transaction(user_id, 'earn', 'karma', points)

    @staticmethod
    def _calculate_points(action_type, params):
        rule = cls.RULES[action_type]
        return rule(params['amount']) if callable(rule) else rule
```

---

### 四、虛藕貨幣管理系統

1. **福幣兌換規則（app/assets/fu_coins.py）**
```python
class FuCoinManager:
    EXCHANGE_RATE = 100  # 1元人民幣=100福幣
    BONUS_RATES = {
        'festival': 1.2,   # 法會期間20%加成
        'vip': 1.1        # VIP會員加成
    }

    @classmethod
    def purchase_coins(cls, user_id, amount, context=None):
        base_coins = amount * cls.EXCHANGE_RATE
        bonus = 1.0
        
        if context:
            if 'is_festival' in context:
                bonus *= cls.BONUS_RATES['festival']
            if 'is_vip' in context:
                bonus *= cls.BONUS_RATES['vip']
                
        total_coins = base_coins * bonus
        
        with db.transaction():
            db.execute(
                "UPDATE user_assets SET fu_coins = fu_coins + %s WHERE user_id = %s",
                (total_coins, user_id)
            )
            log_transaction(user_id, 'purchase', 'fu', total_coins)
```

---

### 五、宗教特色優惠券系統

1. **法會專屬券生成（app/assets/coupons.py）**
```python
class DharmaCouponGenerator:
    SPECIAL_TEMPLATES = {
        '法華經誦讀會': {
            'type': 'percentage',
            'value': 0.15,
            'min_order': 100.00,
            'applicable_to': ['經書', '法物']
        },
        '盂蘭盆節': {
            'type': 'fixed',
            'value': 50.00,
            'applicable_to': ['全部']
        }
    }

    @classmethod
    def generate_festival_coupons(cls, event_name, quantity):
        template = cls.SPECIAL_TEMPLATES[event_name]
        coupons = []
        for _ in range(quantity):
            code = f"DHARMA_{event_name[:3]}_{secrets.token_hex(3).upper()}"
            coupons.append({
                **template,
                'code': code,
                'valid_from': datetime.now(),
                'valid_until': datetime.now() + timedelta(days=30)
            })
        db.bulk_insert('coupons', coupons)
```

---

### 六、Streamlit 前端集成

1. **用戶資產面板（app/components/assets.py）**
```python
def show_assets_panel():
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("功德點", f"{current_user.karma_points} 點", 
                 help="可通過供養、共修等活動積累")
    with col2:
        st.metric("福幣余額", f"¥{current_user.fu_coins:.2f}",
                 help="可用于直接抵扣商品金額")
    with col3:
        if st.button("兌換優惠券"):
            show_coupon_exchange()

def show_coupon_exchange():
    with st.popup("功德兌換"):
        points = st.number_input("輸入兌換點數", min_value=100, step=100)
        coupon_value = points // 100  # 100點=1元優惠券
        if st.button("确認兌換"):
            if current_user.karma_points >= points:
                db.execute("UPDATE user_assets SET karma_points = karma_points - %s", points)
                generate_coupon(current_user.id, coupon_value)
                st.success(f"成功兌換{coupon_value}元優惠券")
```

---

### 七、安全風控措施

1. **交易驗證中間件**
```python
def validate_transaction(user_id, tx_type, asset_type, amount):
    asset = get_user_assets(user_id)
    
    validators = {
        ('redeem', 'karma'): lambda: asset.karma >= amount,
        ('redeem', 'fu'): lambda: asset.fu_coins >= amount,
        ('use', 'coupon'): lambda: check_coupon_validity(amount)
    }
    
    if not validators.get((tx_type, asset_type), lambda: True)():
        raise TransactionError("交易驗證失敗")
```

2. **定時審計任務**
```python
@app.task
def daily_asset_audit():
    # 檢查數據一致性
    discrepancies = db.execute("""
        SELECT u.uid, 
               a.karma_points - t.karma_sum AS karma_diff,
               a.fu_coins - t.fu_sum AS fu_diff
        FROM user_assets a
        JOIN (
            SELECT user_id, 
                   SUM(CASE WHEN asset_type='karma' THEN amount ELSE 0 END) karma_sum,
                   SUM(CASE WHEN asset_type='fu' THEN amount ELSE 0 END) fu_sum
            FROM asset_transactions
            GROUP BY user_id
        ) t ON a.user_id = t.user_id
        WHERE a.karma_points != t.karma_sum OR a.fu_coins != t.fu_sum
    """)
    
    for diff in discrepancies:
        send_alert(f"用戶{diff['uid']}資產異常: 功德點差異{diff['karma_diff']}, 福幣差異{diff['fu_diff']}")
```

---

### 八、宗教特色運營策略

1. **修行獎勵機制**
```python
def meditation_reward_system():
    if st.session_state.get('daily_meditation'):
        KarmaSystem.award_points(current_user.id, 'meditation', duration=30)
        st.toast("完成今日共修，獲得50功德點！")

def generate_dharma_coupon():
    if is_buddhist_festival():  # 判斷佛教節日
        DharmaCouponGenerator.generate_festival_coupons('衛塞節', 1000)
```

---

### 實施步驟建議：
1. 先建立基礎資產管理系統
2. 實現功德點與福幣核心邏輯
3. 開發宗教特色優惠券模板
4. 集成復合支付結算流程
5. 部署安全審計系統
6. 上線前進行全量資產壓力測試

系統特點：
- 三合一支付方式靈活組合
- 深度結合宗教活動場景
- 采用防超額消費設計
- 完整資產變動追溯能力
- 節日專屬運營工具集成

通過此系統，可有效提升用戶粘性并促進宗教物品流通，建議配合定期法會活動進行積分獎勵發放，增強社區參與感。
