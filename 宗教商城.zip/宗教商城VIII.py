# .env 文件
FIREBASE_API_KEY = "AIzaSyB..."
FIREBASE_AUTH_DOMAIN = "your-app.firebaseapp.com"
FIREBASE_PROJECT_ID = "your-app"
import pyrebase
import firebase_admin
from firebase_admin import credentials

config = {
  "apiKey": os.getenv("FIREBASE_API_KEY"),
  "authDomain": os.getenv("FIREBASE_AUTH_DOMAIN"),
  "projectId": os.getenv("FIREBASE_PROJECT_ID"),
  "storageBucket": "",
  "messagingSenderId": "",
  "appId": "",
  "measurementId": ""
}

firebase = pyrebase.initialize_app(config)
auth = firebase.auth()

# 初始化 Admin SDK
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred)
from authlib.integrations.requests_client import OAuth2Session
import streamlit as st

def github_login():
    client = OAuth2Session(
        client_id=os.getenv("GITHUB_CLIENT_ID"),
        client_secret=os.getenv("GITHUB_CLIENT_SECRET"),
        scope="user:email"
    )
    uri, state = client.create_authorization_url(
        "https://github.com/login/oauth/authorize"
    )
    st.session_state['oauth_state'] = state
    return uri

def handle_callback(provider):
    client = OAuth2Session(
        client_id=os.getenv(f"{provider.upper()}_CLIENT_ID"),
        client_secret=os.getenv(f"{provider.upper()}_CLIENT_SECRET")
    )
    token = client.fetch_token(
        request.url,
        authorization_response=request.url,
        state=st.session_state['oauth_state']
    )
    return token
import streamlit as st
from streamlit.components.v1 import html

def oauth_buttons():
    html(f"""
    <script src="https://www.gstatic.com/firebasejs/ui/6.0.1/firebase-ui-auth.js"></script>
    <link type="text/css" rel="stylesheet" href="https://www.gstatic.com/firebasejs/ui/6.0.1/firebase-ui-auth.css" />
    
    <div id="firebaseui-auth-container"></div>
    <script>
    const ui = new firebaseui.auth.AuthUI(firebase.auth());
    ui.start('#firebaseui-auth-container', {{
        signInOptions: [
            firebase.auth.GoogleAuthProvider.PROVIDER_ID,
            firebase.auth.FacebookAuthProvider.PROVIDER_ID,
            firebase.auth.GithubAuthProvider.PROVIDER_ID
        ],
        signInFlow: 'redirect',
        credentialHelper: firebaseui.auth.CredentialHelper.NONE,
        tosUrl: 'https://your-domain.com/tos',
        privacyPolicyUrl: 'https://your-domain.com/privacy'
    }});
    </script>
    """, height=300)
from functools import wraps

def login_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if 'user' not in st.session_state:
            st.error("請先登錄")
            oauth_buttons()
            st.stop()
        return func(*args, **kwargs)
    return wrapper

def handle_auth_state():
    if 'user' not in st.session_state:
        try:
            user_info = auth.get_account_info(st.session_state['token'])
            st.session_state['user'] = user_info['users'][0]
        except:
            pass
CREATE TABLE users (
    uid VARCHAR(255) PRIMARY KEY,
    email VARCHAR(255) UNIQUE,
    provider VARCHAR(50),
    display_name VARCHAR(255),
    avatar_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_verified BOOLEAN DEFAULT FALSE,
    religion_profile JSONB  -- 存儲宗教專屬字段
);
def sync_user(user_info):
    provider_map = {
        'google.com': 'google',
        'facebook.com': 'facebook',
        'github.com': 'github'
    }
    
    user = db.get_user(user_info['email'])
    if not user:
        db.create_user(
            uid=user_info['localId'],
            email=user_info['email'],
            provider=provider_map[user_info['providerId']],
            display_name=user_info.get('displayName'),
            avatar_url=user_info.get('photoUrl')
        )
    return user
from firebase_admin import auth as admin_auth

def verify_token(id_token):
    try:
        decoded_token = admin_auth.verify_id_token(id_token)
        return decoded_token
    except Exception as e:
        st.error(f"Token 驗證失敗: {str(e)}")
        return None
st.session_state.update({
    'cookie': {
        'name': 'oauth_session',
        'key': 'supersecret',
        'expiry_days': 1
    }
})
def dharma_name_check(name):
    with open('data/sacred_names.txt') as f:
        sacred_names = [n.strip() for n in f.readlines()]
    return name in sacred_names

def religious_login():
    st.write("## 法名認證系統")
    dharma_name = st.text_input("請輸入法名")
    if st.button("驗證"):
        if dharma_name_check(dharma_name):
            st.session_state['religious_verified'] = True
def karma_points_system(user_id):
    points = db.execute(f"""
        SELECT SUM(points) 
        FROM religious_actions 
        WHERE user_id = '{user_id}'
    """)
    st.write(f"您當前的功德積分：{points}")
st.set_page_config(
    page_title="宗教商城",
    page_icon="🕉️",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        'Report a bug': "https://your-domain.com/support",
        'About': "本系統專為宗教團體設計"
    }
)
