以下是為您的宗教云商城添加多平台 OAuth 登錄的完整實現方案，采用 Authlib + Firebase 混合模式：

---

### 一、技術架構升級
```mermaid
graph TD
    A[Streamlit前端] --> B[Firebase Auth]
    B --> C[Facebook OAuth]
    B --> D[Google OAuth]
    B --> E[GitHub OAuth]
    A --> F[Authlib 驗證]
    F --> G[用戶數據庫]
```

---

### 二、Firebase 基礎配置

1. **創建 Firebase 項目**
- 前往 [Firebase 控制台](https://console.firebase.google.com/) 新建項目
- 啟用 Facebook/Google/GitHub 登錄方式
- 獲取 Web 配置信息：
```python
# .env 文件
FIREBASE_API_KEY = "AIzaSyB..."
FIREBASE_AUTH_DOMAIN = "your-app.firebaseapp.com"
FIREBASE_PROJECT_ID = "your-app"
```

2. **安裝 SDK**
```bash
pip install pyrebase4 firebase_admin
```

---

### 三、OAuth 集成核心代碼

1. **Firebase 初始化（app/firebase.py）**
```python
import pyrebase
import firebase_admin
from firebase_admin import credentials

config = {
  "apiKey": os.getenv("FIREBASE_API_KEY"),
  "authDomain": os.getenv("FIREBASE_AUTH_DOMAIN"),
  "projectId": os.getenv("FIREBASE_PROJECT_ID"),
  "storageBucket": "",
  "messagingSenderId": "",
  "appId": "",
  "measurementId": ""
}

firebase = pyrebase.initialize_app(config)
auth = firebase.auth()

# 初始化 Admin SDK
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred)
```

2. **OAuth 路由處理器（app/auth.py）**
```python
from authlib.integrations.requests_client import OAuth2Session
import streamlit as st

def github_login():
    client = OAuth2Session(
        client_id=os.getenv("GITHUB_CLIENT_ID"),
        client_secret=os.getenv("GITHUB_CLIENT_SECRET"),
        scope="user:email"
    )
    uri, state = client.create_authorization_url(
        "https://github.com/login/oauth/authorize"
    )
    st.session_state['oauth_state'] = state
    return uri

def handle_callback(provider):
    client = OAuth2Session(
        client_id=os.getenv(f"{provider.upper()}_CLIENT_ID"),
        client_secret=os.getenv(f"{provider.upper()}_CLIENT_SECRET")
    )
    token = client.fetch_token(
        request.url,
        authorization_response=request.url,
        state=st.session_state['oauth_state']
    )
    return token
```

---

### 四、Streamlit 登錄界面集成

1. **登錄組件（app/components/login.py）**
```python
import streamlit as st
from streamlit.components.v1 import html

def oauth_buttons():
    html(f"""
    <script src="https://www.gstatic.com/firebasejs/ui/6.0.1/firebase-ui-auth.js"></script>
    <link type="text/css" rel="stylesheet" href="https://www.gstatic.com/firebasejs/ui/6.0.1/firebase-ui-auth.css" />
    
    <div id="firebaseui-auth-container"></div>
    <script>
    const ui = new firebaseui.auth.AuthUI(firebase.auth());
    ui.start('#firebaseui-auth-container', {{
        signInOptions: [
            firebase.auth.GoogleAuthProvider.PROVIDER_ID,
            firebase.auth.FacebookAuthProvider.PROVIDER_ID,
            firebase.auth.GithubAuthProvider.PROVIDER_ID
        ],
        signInFlow: 'redirect',
        credentialHelper: firebaseui.auth.CredentialHelper.NONE,
        tosUrl: 'https://your-domain.com/tos',
        privacyPolicyUrl: 'https://your-domain.com/privacy'
    }});
    </script>
    """, height=300)
```

2. **登錄狀態管理（app/auth/session.py）**
```python
from functools import wraps

def login_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if 'user' not in st.session_state:
            st.error("請先登錄")
            oauth_buttons()
            st.stop()
        return func(*args, **kwargs)
    return wrapper

def handle_auth_state():
    if 'user' not in st.session_state:
        try:
            user_info = auth.get_account_info(st.session_state['token'])
            st.session_state['user'] = user_info['users'][0]
        except:
            pass
```

---

### 五、各平台 OAuth 配置指南

1. **Facebook 開發者設置**
- 創建應用：https://developers.facebook.com/
- 添加 `Facebook 登錄` 產品
- 配置有效 OAuth 重定向 URI：
  `https://{YOUR_DOMAIN}/__/auth/handler`

2. **Google Cloud 配置**
- 進入 API 憑據頁面：https://console.cloud.google.com/apis/credentials
- 創建 OAuth 2.0 客戶端 ID
- 授權 JavaScript 來源：`https://{YOUR_DOMAIN}`

3. **GitHub OAuth Apps**
- 創建應用：https://github.com/settings/applications/new
- 回調 URL 設置：
  `https://{YOUR_DOMAIN}/_oauth`

---

### 六、用戶數據整合方案

1. **數據庫 Schema 設計**
```sql
CREATE TABLE users (
    uid VARCHAR(255) PRIMARY KEY,
    email VARCHAR(255) UNIQUE,
    provider VARCHAR(50),
    display_name VARCHAR(255),
    avatar_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_verified BOOLEAN DEFAULT FALSE,
    religion_profile JSONB  -- 存儲宗教專屬字段
);
```

2. **用戶同步邏輯**
```python
def sync_user(user_info):
    provider_map = {
        'google.com': 'google',
        'facebook.com': 'facebook',
        'github.com': 'github'
    }
    
    user = db.get_user(user_info['email'])
    if not user:
        db.create_user(
            uid=user_info['localId'],
            email=user_info['email'],
            provider=provider_map[user_info['providerId']],
            display_name=user_info.get('displayName'),
            avatar_url=user_info.get('photoUrl')
        )
    return user
```

---

### 七、安全增強措施

1. **JWT 驗證中間件**
```python
from firebase_admin import auth as admin_auth

def verify_token(id_token):
    try:
        decoded_token = admin_auth.verify_id_token(id_token)
        return decoded_token
    except Exception as e:
        st.error(f"Token 驗證失敗: {str(e)}")
        return None
```

2. **會話安全配置**
```python
st.session_state.update({
    'cookie': {
        'name': 'oauth_session',
        'key': 'supersecret',
        'expiry_days': 1
    }
})
```

---

### 八、宗教特色登錄擴展

1. **法名驗證系統**
```python
def dharma_name_check(name):
    with open('data/sacred_names.txt') as f:
        sacred_names = [n.strip() for n in f.readlines()]
    return name in sacred_names

def religious_login():
    st.write("## 法名認證系統")
    dharma_name = st.text_input("請輸入法名")
    if st.button("驗證"):
        if dharma_name_check(dharma_name):
            st.session_state['religious_verified'] = True
```

2. **功德積分系統**
```python
def karma_points_system(user_id):
    points = db.execute(f"""
        SELECT SUM(points) 
        FROM religious_actions 
        WHERE user_id = '{user_id}'
    """)
    st.write(f"您當前的功德積分：{points}")
```

---

### 部署注意事項

1. **HTTPS 強制配置**
```nginx
server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$host$request_uri;
}
```

2. **環境變量管理**
```bash
# Dockerfile
ENV FIREBASE_API_KEY=$FIREBASE_API_KEY
ENV GITHUB_CLIENT_ID=$GITHUB_CLIENT_ID
# ...其他敏感變量...
```

3. **跨域配置示例**
```python
st.set_page_config(
    page_title="宗教商城",
    page_icon="🕉️",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        'Report a bug': "https://your-domain.com/support",
        'About': "本系統專為宗教團體設計"
    }
)
```

---

此方案優勢：
1. 利用 Firebase 統一管理多平台認證
2. 保留直接使用 Authlib 的靈活性
3. 符合宗教用戶特殊身份驗證需求
4. 完整的安全防護措施
5. 用戶數據與宗教屬性深度整合

實施步驟建議：
1. 先完成 Firebase 基礎配置
2. 測試各平台 OAuth 流程
3. 實現用戶數據同步
4. 添加宗教特色驗證系統
5. 進行全面安全審計
